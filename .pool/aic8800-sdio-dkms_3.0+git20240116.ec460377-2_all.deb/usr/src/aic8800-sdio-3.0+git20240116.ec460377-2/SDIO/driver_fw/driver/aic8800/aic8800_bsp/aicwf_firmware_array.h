int aicwf_get_firmware_array(char* fw_name, u32 **fw_buf);


